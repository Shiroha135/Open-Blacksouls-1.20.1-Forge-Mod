Lydia from TESV: Skyrim (c) Bethesda
Extracted, converted, rigged by Tokami-Fuko
For fanar only.
Have fun!

Torcs by cleanzor
Steel armor high textures aMidianBorn